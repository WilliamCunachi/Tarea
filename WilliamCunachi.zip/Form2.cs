﻿using _07_Pais_Ciudad.Controllers;
using _07_Pais_Ciudad.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _07_Pais_Ciudad
{
    public partial class Form2 : Form
    {
        private string id;
        private CiudadesController _ciudadesController = new CiudadesController();

        public Form2(string id)
        {
            InitializeComponent();

            this.id = id;

            if (string.IsNullOrEmpty(id))
            {
                // Si el ID es nulo o vacío, se está agregando una nueva ciudad
                this.Text = "Agregar Ciudad";
            }
            else
            {
                // Si el ID no es nulo, se está editando una ciudad existente
                this.Text = "Editar Ciudad";
                // Aquí puedes cargar la ciudad existente usando el ID
                CargarCiudad(id);
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            PaisesControllers _paisesController = new PaisesControllers();
            comboBox1.DataSource = _paisesController.todos();
            comboBox1.DisplayMember = "Detalle";
            comboBox1.ValueMember = "IdPais";

            // Cargar la ciudad si el ID no es null o vacío
            if (!string.IsNullOrEmpty(this.id))
            {
                CiudadesModel ciudad = _ciudadesController.ObtenerCiudadPorId(int.Parse(this.id));
                if (ciudad != null)
                {
                    txtNombreCiudad.Text = ciudad.Detalle;
                    comboBox1.SelectedValue = ciudad.idPais;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string detalleCiudad = txtNombreCiudad .Text; // Nombre de la ciudad
            int idPais = (int)comboBox1.SelectedValue; // Id del país seleccionado
            int idCiudad = int.Parse(this.id); // El id de la ciudad que se está editando

            if (!string.IsNullOrEmpty(detalleCiudad))
            {
                bool actualizado = _ciudadesController.ActualizarCiudad(idCiudad, detalleCiudad, idPais);

                if (actualizado)
                {
                    MessageBox.Show("Ciudad actualizada correctamente.");
                }
                else
                {
                    MessageBox.Show("Error al actualizar la ciudad.");
                }
            }
            else
            {
                MessageBox.Show("Debe ingresar un nombre de ciudad.");
            }
        }
    }
    }

    